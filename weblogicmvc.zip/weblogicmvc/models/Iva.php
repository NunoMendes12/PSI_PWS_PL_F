<?php

class Iva extends \ActiveRecord\Model
{

}