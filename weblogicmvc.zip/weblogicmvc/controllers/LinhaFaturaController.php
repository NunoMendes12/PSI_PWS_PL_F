<?php

class LinhaFaturaController
{

}